import { useState, useEffect } from "react";
import { ref, push, onValue } from "firebase/database";
import { database } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";
import AuthModal from "@/components/AuthModal";
import Footer from "@/components/Footer";

const inputStyle: React.CSSProperties = {
  width: "100%", padding: "13px 15px", background: "#1a1a1a",
  border: "1px solid #333", borderRadius: 8, color: "#fff",
  fontSize: 14, fontFamily: "Poppins, sans-serif", marginBottom: 14,
  outline: "none", boxSizing: "border-box",
};

export default function Scrims() {
  const { user } = useAuth();
  const [showAuth, setShowAuth] = useState(false);
  const [formEnabled, setFormEnabled] = useState(false);
  const [settingsLoaded, setSettingsLoaded] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [confirm1, setConfirm1] = useState(false);
  const [confirm2, setConfirm2] = useState(false);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [form, setForm] = useState({
    teamName: "", teamIglUid: "", teamIglIgn: "", managerContact: "",
  });

  useEffect(() => {
    const r = ref(database, "settings/scrimFormEnabled");
    const unsub = onValue(r, (snap) => {
      setFormEnabled(snap.val() === true);
      setSettingsLoaded(true);
    });
    return unsub;
  }, []);

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) { setShowAuth(true); return; }
    if (!confirm1 || !confirm2) { alert("Please confirm both checkboxes."); return; }
    setSubmitting(true);
    try {
      let teamLogo = "";
      if (logoFile) {
        teamLogo = await new Promise<string>((res, rej) => {
          const reader = new FileReader();
          reader.onload = () => res(reader.result as string);
          reader.onerror = () => rej(reader.error);
          reader.readAsDataURL(logoFile);
        });
      }
      const payload = {
        ...form, teamLogo,
        userId: user.uid, userEmail: user.email, userName: user.displayName || "",
        status: "Pending", type: "scrim",
        registeredAt: new Date().toISOString(),
      };
      await push(ref(database, "scrims"), payload);
      await push(ref(database, `notifications/${user.uid}`), {
        message: "⚔️ Your Scrim Booking has been submitted!",
        status: "Pending", type: "scrim",
        createdAt: new Date().toISOString(),
      });
      setSubmitted(true);
    } catch (err: any) {
      alert("❌ Error: " + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  if (!settingsLoaded) return <div style={{ minHeight: "80vh", display: "flex", alignItems: "center", justifyContent: "center" }}><div style={{ width: 40, height: 40, border: "3px solid #ff2b2b", borderTopColor: "transparent", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} /></div>;

  return (
    <>
      {showAuth && <AuthModal onClose={() => setShowAuth(false)} />}
      <section style={{ minHeight: "50vh", display: "flex", alignItems: "center", justifyContent: "center", textAlign: "center", padding: 20, background: "linear-gradient(rgba(0,0,0,.8),rgba(0,0,0,.9)), url('https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1600&q=80') center/cover" }}>
        <div style={{ animation: "fadeUp 0.8s ease" }}>
          <h1 style={{ fontSize: "clamp(1.8rem,5vw,3rem)", fontWeight: 900, color: "#ff2b2b", textShadow: "0 0 15px #ff2b2b" }}>SCRIMS REGISTRATION</h1>
          <h2 style={{ margin: "15px 0" }}>Book Your Practice Match</h2>
          <p style={{ color: "#ddd" }}>Daily competitive practice matches for serious teams.</p>
        </div>
      </section>

      <section style={{ maxWidth: 600, margin: "60px auto", padding: "0 20px 60px" }}>
        {!formEnabled ? (
          <div style={{ textAlign: "center", padding: "80px 20px" }}>
            <div style={{ fontSize: 60, marginBottom: 20 }}>⚔️</div>
            <h2 style={{ color: "#ff2b2b", fontSize: "2rem", fontWeight: 900, letterSpacing: 4 }}>COMING SOON</h2>
            <p style={{ color: "#aaa", marginTop: 15 }}>Scrim booking coming soon. Stay tuned!</p>
          </div>
        ) : submitted ? (
          <div style={{ textAlign: "center", padding: "60px 20px" }}>
            <div style={{ fontSize: 60, marginBottom: 20 }}>✅</div>
            <h2 style={{ color: "#22c55e", fontSize: "1.8rem", marginBottom: 15 }}>Booking Submitted!</h2>
            <p style={{ color: "#aaa" }}>Your scrim booking has been submitted. Check notifications for updates.</p>
          </div>
        ) : (
          <>
            <h2 style={{ color: "#ff2b2b", fontWeight: 900, textAlign: "center", marginBottom: 8, letterSpacing: 2 }}>SCRIM BOOKING FORM</h2>
            <p style={{ color: "#aaa", textAlign: "center", marginBottom: 30, fontSize: 14 }}>Fill all required fields carefully.</p>

            {!user && (
              <div style={{ background: "rgba(255,43,43,0.1)", border: "1px solid rgba(255,43,43,0.3)", borderRadius: 8, padding: "12px 18px", marginBottom: 20, textAlign: "center" }}>
                <p style={{ color: "#ff2b2b", fontSize: 14 }}>⚠️ <button onClick={() => setShowAuth(true)} style={{ background: "none", border: "none", color: "#ff2b2b", fontWeight: 700, cursor: "pointer", textDecoration: "underline", fontFamily: "Poppins, sans-serif" }}>Login</button> to submit this form.</p>
              </div>
            )}

            <form onSubmit={handleSubmit}>
              <label style={{ color: "#aaa", fontSize: 12, display: "block", marginBottom: 4 }}>TEAM NAME (REQUIRED)</label>
              <input style={inputStyle} type="text" placeholder="Team Name" value={form.teamName} onChange={e => set("teamName", e.target.value)} required />

              <label style={{ color: "#aaa", fontSize: 12, display: "block", marginBottom: 4 }}>TEAM LOGO (OPTIONAL)</label>
              <input style={{ ...inputStyle, padding: "10px 15px" }} type="file" accept="image/*" onChange={e => setLogoFile(e.target.files?.[0] || null)} />

              <label style={{ color: "#aaa", fontSize: 12, display: "block", marginBottom: 4 }}>TEAM IGL UID (REQUIRED)</label>
              <input style={inputStyle} type="text" placeholder="Team IGL UID" value={form.teamIglUid} onChange={e => set("teamIglUid", e.target.value)} required />

              <label style={{ color: "#aaa", fontSize: 12, display: "block", marginBottom: 4 }}>TEAM IGL IN GAME NAME / IGN (REQUIRED)</label>
              <input style={inputStyle} type="text" placeholder="Team IGL IGN" value={form.teamIglIgn} onChange={e => set("teamIglIgn", e.target.value)} required />

              <label style={{ color: "#aaa", fontSize: 12, display: "block", marginBottom: 4 }}>TEAM IGL/MANAGER CONTACT NO. (WhatsApp No.) (REQUIRED)</label>
              <input style={inputStyle} type="tel" placeholder="WhatsApp Number" value={form.managerContact} onChange={e => set("managerContact", e.target.value)} required />

              <div style={{ background: "#1a1a1a", border: "1px solid #333", borderRadius: 8, padding: 20, marginBottom: 14 }}>
                <label style={{ display: "flex", alignItems: "flex-start", gap: 12, cursor: "pointer", marginBottom: 12 }}>
                  <input type="checkbox" checked={confirm1} onChange={e => setConfirm1(e.target.checked)} style={{ width: 18, height: 18, marginTop: 2, accentColor: "#ff2b2b", flexShrink: 0 }} />
                  <span style={{ color: "#ddd", fontSize: 14 }}>I confirm all details are correct.</span>
                </label>
                <label style={{ display: "flex", alignItems: "flex-start", gap: 12, cursor: "pointer" }}>
                  <input type="checkbox" checked={confirm2} onChange={e => setConfirm2(e.target.checked)} style={{ width: 18, height: 18, marginTop: 2, accentColor: "#ff2b2b", flexShrink: 0 }} />
                  <span style={{ color: "#ddd", fontSize: 14 }}>I agree to PRIME AUTHORITY Tournament Rules &amp; Regulations.</span>
                </label>
              </div>

              <button type="submit" disabled={submitting || !confirm1 || !confirm2} style={{
                width: "100%", padding: "15px", background: "#ff2b2b", border: "none",
                borderRadius: 8, color: "#fff", fontSize: 16, fontWeight: 700,
                cursor: (submitting || !confirm1 || !confirm2) ? "not-allowed" : "pointer",
                fontFamily: "Poppins, sans-serif", opacity: (submitting || !confirm1 || !confirm2) ? 0.6 : 1,
              }}>
                {submitting ? "SUBMITTING..." : "BOOK SCRIM SLOT"}
              </button>
            </form>
          </>
        )}
      </section>
      <Footer />
    </>
  );
}
