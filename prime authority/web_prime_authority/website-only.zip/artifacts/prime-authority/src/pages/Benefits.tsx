import Footer from "@/components/Footer";

export default function Benefits() {
  const benefits = [
    { icon: "🏆", title: "Professional Management", items: ["Dedicated management support for every team.", "Well-organized communication and tournament coordination.", "Fair and transparent decision-making."] },
    { icon: "🎯", title: "Tournament Opportunities", items: ["Priority entry into scrims, custom rooms, and competitive tournaments.", "Opportunities to participate in official and third-party events.", "Performance-based promotion to higher-level competitions."] },
    { icon: "📈", title: "Brand Growth", items: ["Promotion through PRIME AUTHORITY's social media platforms.", "Team highlights, posters, and promotional content.", "Increased exposure for players and teams."] },
    { icon: "🎨", title: "Media & Design Support", items: ["Professional team posters and match graphics.", "Tournament announcements and result posts.", "Branding support for selected teams."] },
    { icon: "🤝", title: "Sponsorship Opportunities", items: ["Eligible teams may receive sponsorship support based on performance, consistency, and professionalism.", "Future partnership opportunities with brands and event organizers."] },
    { icon: "🎥", title: "Content Support", items: ["Feature opportunities on official PRIME AUTHORITY platforms.", "Content collaboration for top-performing teams.", "Promotion of outstanding gameplay and achievements."] },
    { icon: "🛡️", title: "Professional Environment", items: ["Strict anti-toxicity policy.", "Respectful and disciplined community.", "Equal opportunities based on performance—not favoritism."] },
    { icon: "📊", title: "Performance Evaluation", items: ["Regular performance reviews.", "Feedback from management.", "Growth opportunities for dedicated teams."] },
    { icon: "🚀", title: "Career Development", items: ["Chance to represent PRIME AUTHORITY in major competitions.", "Opportunity to build a strong esports profile.", "Long-term support for serious and committed players."] },
  ];

  return (
    <>
      <section style={{ minHeight: "50vh", display: "flex", alignItems: "center", justifyContent: "center", textAlign: "center", padding: 20, background: "linear-gradient(rgba(0,0,0,.8),rgba(0,0,0,.9)), url('https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1600&q=80') center/cover" }}>
        <div style={{ animation: "fadeUp 0.8s ease" }}>
          <h1 style={{ fontSize: "clamp(1.8rem,5vw,3rem)", fontWeight: 900, color: "#ff2b2b", textShadow: "0 0 15px #ff2b2b" }}>WHY JOIN PRIME AUTHORITY?</h1>
          <p style={{ color: "#ddd", maxWidth: 600, margin: "15px auto", lineHeight: 1.7 }}>At PRIME AUTHORITY, we don't just recruit teams—we build long-term champions.</p>
        </div>
      </section>

      <section style={{ maxWidth: 900, margin: "60px auto", padding: "0 20px 60px" }}>
        <h2 style={{ color: "#ff2b2b", fontWeight: 900, textAlign: "center", marginBottom: 40, fontSize: "1.5rem", letterSpacing: 2 }}>Benefits of Joining PRIME AUTHORITY</h2>
        <div style={{ display: "grid", gap: 20, gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))" }}>
          {benefits.map(({ icon, title, items }) => (
            <div key={title} style={{ background: "#111", border: "1px solid #222", borderRadius: 12, padding: 25 }}>
              <h3 style={{ color: "#ff2b2b", marginBottom: 12 }}>{icon} {title}</h3>
              <ul style={{ paddingLeft: 18 }}>
                {items.map(item => <li key={item} style={{ color: "#ccc", fontSize: 14, lineHeight: 1.6, marginBottom: 6 }}>{item}</li>)}
              </ul>
            </div>
          ))}
        </div>
        <div style={{ background: "#111", border: "1px solid #222", borderRadius: 12, padding: 30, marginTop: 20, textAlign: "center" }}>
          <h3 style={{ color: "#ff2b2b", marginBottom: 12 }}>Our Promise</h3>
          <p style={{ color: "#ccc", lineHeight: 1.7 }}>We value Discipline, Loyalty, Consistency, and Performance above everything else. Every team is given a fair opportunity to prove itself and grow within the organization.</p>
          <p style={{ color: "#aaa", marginTop: 10, fontSize: 13 }}>Join PRIME AUTHORITY and become part of a professional esports community built for champions.</p>
        </div>
      </section>
      <Footer />
    </>
  );
}
