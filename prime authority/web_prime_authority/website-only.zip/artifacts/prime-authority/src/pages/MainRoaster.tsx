import Footer from "@/components/Footer";

export default function MainRoaster() {
  return (
    <>
      <section style={{ minHeight: "80vh", display: "flex", alignItems: "center", justifyContent: "center", textAlign: "center", padding: 20, background: "linear-gradient(rgba(0,0,0,.8),rgba(0,0,0,.9)), url('https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1600&q=80') center/cover" }}>
        <div style={{ animation: "fadeUp 0.8s ease" }}>
          <h1 style={{ fontSize: "clamp(2rem,6vw,3.5rem)", fontWeight: 900, color: "#ff2b2b", textShadow: "0 0 20px #ff2b2b" }}>MAIN ROASTER</h1>
          <h2 style={{ margin: "20px 0", fontSize: "1.5rem" }}>Coming Soon</h2>
          <p style={{ color: "#ddd", maxWidth: 500, margin: "0 auto" }}>Our official roster is being prepared. Check back soon for the full Prime Authority team reveal.</p>
        </div>
      </section>
      <Footer />
    </>
  );
}
