import { useState } from "react";
import { ref, push } from "firebase/database";
import { database, auth } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";
import AuthModal from "@/components/AuthModal";
import Footer from "@/components/Footer";

const inputStyle: React.CSSProperties = {
  width: "100%", padding: "13px 15px", background: "#1a1a1a",
  border: "1px solid #333", borderRadius: 8, color: "#fff",
  fontSize: 14, fontFamily: "Poppins, sans-serif", marginBottom: 14,
  outline: "none", boxSizing: "border-box",
};

export default function Join() {
  const { user } = useAuth();
  const [showAuth, setShowAuth] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    teamName: "", teamRegion: "", managerIgn: "", managerFullName: "",
    totalPlayers: "", previousOrganization: "", tournamentExperience: "",
    bestTournamentResult: "", preferredPlayTime: "", whatsappContact: "", emailAddress: "",
  });
  const [logoFile, setLogoFile] = useState<File | null>(null);

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) { setShowAuth(true); return; }
    setSubmitting(true);
    try {
      let teamLogo = "";
      if (logoFile) {
        teamLogo = await new Promise<string>((res, rej) => {
          const reader = new FileReader();
          reader.onload = () => res(reader.result as string);
          reader.onerror = () => rej(reader.error);
          reader.readAsDataURL(logoFile);
        });
      }
      const payload = {
        ...form,
        teamLogo,
        userId: user.uid,
        userEmail: user.email,
        userName: user.displayName || "",
        status: "Pending",
        createdAt: new Date().toISOString(),
      };
      await push(ref(database, "applications"), payload);
      // Send notification to user
      await push(ref(database, `notifications/${user.uid}`), {
        message: "✅ Your join application has been submitted!",
        status: "Pending",
        type: "join",
        createdAt: new Date().toISOString(),
      });
      setSubmitted(true);
    } catch (err: any) {
      alert("❌ Error: " + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) return (
    <div style={{ minHeight: "80vh", display: "flex", alignItems: "center", justifyContent: "center", textAlign: "center", padding: 20 }}>
      <div>
        <div style={{ fontSize: 60, marginBottom: 20 }}>✅</div>
        <h2 style={{ color: "#22c55e", fontSize: "1.8rem", marginBottom: 15 }}>Application Submitted!</h2>
        <p style={{ color: "#aaa" }}>Our management team will review your application. Check notifications for updates.</p>
      </div>
    </div>
  );

  return (
    <>
      {showAuth && <AuthModal onClose={() => setShowAuth(false)} />}
      <section style={{ minHeight: "50vh", display: "flex", alignItems: "center", justifyContent: "center", textAlign: "center", padding: 20, background: "linear-gradient(rgba(0,0,0,.8),rgba(0,0,0,.9)), url('https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1600&q=80') center/cover" }}>
        <div style={{ animation: "fadeUp 0.8s ease" }}>
          <h1 style={{ fontSize: "clamp(1.8rem,5vw,3rem)", fontWeight: 900, color: "#ff2b2b", textShadow: "0 0 15px #ff2b2b" }}>JOIN PRIME AUTHORITY</h1>
          <h2 style={{ margin: "15px 0", fontSize: "1.3rem" }}>Become Part of Our Competitive Family</h2>
          <p style={{ color: "#ddd", fontSize: 16 }}>Fill out the recruitment form and become a part of Prime Authority.</p>
        </div>
      </section>

      <section style={{ maxWidth: 600, margin: "60px auto", padding: "0 20px 60px" }}>
        <h2 style={{ color: "#ff2b2b", fontWeight: 900, textAlign: "center", marginBottom: 8, letterSpacing: 2 }}>TEAM RECRUITMENT FORM</h2>
        <p style={{ color: "#aaa", textAlign: "center", marginBottom: 30, fontSize: 14 }}>Complete all details carefully. Our management team will review your application.</p>

        {!user && (
          <div style={{ background: "rgba(255,43,43,0.1)", border: "1px solid rgba(255,43,43,0.3)", borderRadius: 8, padding: "12px 18px", marginBottom: 20, textAlign: "center" }}>
            <p style={{ color: "#ff2b2b", fontSize: 14 }}>⚠️ You need to <button onClick={() => setShowAuth(true)} style={{ background: "none", border: "none", color: "#ff2b2b", fontWeight: 700, cursor: "pointer", textDecoration: "underline", fontFamily: "Poppins, sans-serif" }}>login</button> to submit this form.</p>
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <input style={inputStyle} type="text" placeholder="Team Name *" value={form.teamName} onChange={e => set("teamName", e.target.value)} required />
          <label style={{ color: "#aaa", fontSize: 13, display: "block", marginBottom: 6 }}>Team Logo (Optional)</label>
          <input style={{ ...inputStyle, padding: "10px 15px" }} type="file" accept="image/*" onChange={e => setLogoFile(e.target.files?.[0] || null)} />
          <input style={inputStyle} type="text" placeholder="Team Region / State *" value={form.teamRegion} onChange={e => set("teamRegion", e.target.value)} required />
          <input style={inputStyle} type="text" placeholder="Team Manager / IGL Name (IGN) *" value={form.managerIgn} onChange={e => set("managerIgn", e.target.value)} required />
          <input style={inputStyle} type="text" placeholder="Team Manager / IGL Full Name (Optional)" value={form.managerFullName} onChange={e => set("managerFullName", e.target.value)} />
          <input style={inputStyle} type="number" placeholder="Total Players In Team *" value={form.totalPlayers} onChange={e => set("totalPlayers", e.target.value)} required />
          <input style={inputStyle} type="text" placeholder="Previous Organization (Optional)" value={form.previousOrganization} onChange={e => set("previousOrganization", e.target.value)} />
          <select style={{ ...inputStyle, appearance: "none" }} value={form.tournamentExperience} onChange={e => set("tournamentExperience", e.target.value)} required>
            <option value="">Tournament Experience (Yes/No) *</option>
            <option>Yes</option>
            <option>No</option>
          </select>
          <input style={inputStyle} type="text" placeholder="Best Tournament Result (Optional)" value={form.bestTournamentResult} onChange={e => set("bestTournamentResult", e.target.value)} />
          <select style={{ ...inputStyle, appearance: "none" }} value={form.preferredPlayTime} onChange={e => set("preferredPlayTime", e.target.value)} required>
            <option value="">Preferred Play Time *</option>
            <option>1-3hr.</option>
            <option>3-5hr.</option>
            <option>5-8hr.</option>
            <option>8hr.+</option>
          </select>
          <input style={inputStyle} type="tel" placeholder="WhatsApp Contact Number *" value={form.whatsappContact} onChange={e => set("whatsappContact", e.target.value)} required />
          <input style={inputStyle} type="email" placeholder="Email Address *" value={form.emailAddress} onChange={e => set("emailAddress", e.target.value)} required />
          <button type="submit" disabled={submitting} style={{
            width: "100%", padding: "15px", background: "#ff2b2b", border: "none",
            borderRadius: 8, color: "#fff", fontSize: 16, fontWeight: 700,
            cursor: submitting ? "not-allowed" : "pointer", fontFamily: "Poppins, sans-serif",
            opacity: submitting ? 0.7 : 1, marginTop: 5,
          }}>
            {submitting ? "SUBMITTING..." : "APPLY NOW"}
          </button>
        </form>
      </section>
      <Footer />
    </>
  );
}
