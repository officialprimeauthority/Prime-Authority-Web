import Footer from "@/components/Footer";

const InstagramLogo = () => (
  <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
    <defs>
      <radialGradient id="ig1" cx="30%" cy="107%" r="150%">
        <stop offset="0%" stopColor="#fdf497"/>
        <stop offset="5%" stopColor="#fdf497"/>
        <stop offset="45%" stopColor="#fd5949"/>
        <stop offset="60%" stopColor="#d6249f"/>
        <stop offset="90%" stopColor="#285AEB"/>
      </radialGradient>
    </defs>
    <rect width="24" height="24" rx="6" fill="url(#ig1)"/>
    <circle cx="12" cy="12" r="4.5" stroke="#fff" strokeWidth="1.8" fill="none"/>
    <circle cx="17.5" cy="6.5" r="1.2" fill="#fff"/>
    <rect x="2.5" y="2.5" width="19" height="19" rx="5" stroke="#fff" strokeWidth="1.8" fill="none"/>
  </svg>
);

const WhatsAppLogo = () => (
  <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
    <rect width="24" height="24" rx="6" fill="#25D366"/>
    <path d="M12 4.5C7.86 4.5 4.5 7.86 4.5 12c0 1.37.36 2.66.99 3.77L4.5 19.5l3.82-1c1.07.58 2.3.92 3.68.92 4.14 0 7.5-3.36 7.5-7.5S16.14 4.5 12 4.5z" fill="#fff"/>
    <path d="M16.23 14.45c-.2-.1-1.18-.58-1.36-.65-.18-.07-.31-.1-.44.1-.13.2-.5.65-.62.78-.11.13-.23.15-.43.05a5.4 5.4 0 0 1-1.6-1c-.3-.26-.62-.56-.85-.88-.13-.2-.01-.31.1-.41.1-.09.2-.23.3-.35.1-.12.13-.2.2-.33.06-.13.03-.25-.02-.35-.05-.1-.44-1.07-.6-1.46-.16-.38-.32-.33-.44-.34h-.37c-.13 0-.34.05-.52.25-.18.2-.68.66-.68 1.62s.7 1.88.8 2.01c.1.13 1.37 2.1 3.32 2.94.46.2.82.32 1.1.41.46.15.88.13 1.21.08.37-.06 1.14-.47 1.3-.92.16-.45.16-.84.11-.92-.05-.08-.18-.13-.38-.23z" fill="#25D366"/>
  </svg>
);

const EmailLogo = () => (
  <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
    <rect width="24" height="24" rx="6" fill="#EA4335"/>
    <path d="M4 8l8 5 8-5" stroke="#fff" strokeWidth="1.5" fill="none" strokeLinecap="round"/>
    <rect x="4" y="7" width="16" height="11" rx="2" stroke="#fff" strokeWidth="1.5" fill="none"/>
  </svg>
);

const WHATSAPP_LINK = "https://whatsapp.com/channel/0029Vb7JsfwGZNCmkbNDw73c";

export default function Contact() {
  return (
    <>
      <section style={{ padding: "80px 20px", maxWidth: 640, margin: "0 auto", textAlign: "center" }}>
        <h1 style={{ color: "#ff2b2b", fontWeight: 900, fontSize: "2rem", letterSpacing: 2, marginBottom: 10 }}>
          CONTACT PRIME AUTHORITY
        </h1>
        <p style={{ color: "#aaa", marginBottom: 40 }}>Reach out to us through any of the channels below.</p>

        <div style={{ display: "flex", flexDirection: "column", gap: 15 }}>

          {/* Instagram */}
          <div style={{ background: "#111", border: "1px solid #222", borderRadius: 12, padding: "20px 30px", display: "flex", alignItems: "center", gap: 20 }}>
            <InstagramLogo />
            <div style={{ textAlign: "left" }}>
              <p style={{ color: "#ff2b2b", fontWeight: 700, fontSize: 14, marginBottom: 2 }}>Instagram</p>
              <p style={{ color: "#aaa", fontSize: 14 }}>Coming Soon</p>
            </div>
          </div>

          {/* WhatsApp — clickable link */}
          <a
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noopener noreferrer"
            style={{ background: "#111", border: "1px solid #25D366", borderRadius: 12, padding: "20px 30px", display: "flex", alignItems: "center", gap: 20, textDecoration: "none", transition: "box-shadow .3s" }}
            onMouseEnter={e => (e.currentTarget.style.boxShadow = "0 0 20px rgba(37,211,102,0.3)")}
            onMouseLeave={e => (e.currentTarget.style.boxShadow = "none")}
          >
            <WhatsAppLogo />
            <div style={{ textAlign: "left" }}>
              <p style={{ color: "#25D366", fontWeight: 700, fontSize: 14, marginBottom: 2 }}>WhatsApp</p>
              <p style={{ color: "#fff", fontSize: 14, fontWeight: 600 }}>Join WhatsApp Community For Updates</p>
              <p style={{ color: "#aaa", fontSize: 12, marginTop: 3 }}>Click to open → Follow PRIME AUTHORITY channel</p>
            </div>
          </a>

          {/* Email */}
          <div style={{ background: "#111", border: "1px solid #222", borderRadius: 12, padding: "20px 30px", display: "flex", alignItems: "center", gap: 20 }}>
            <EmailLogo />
            <div style={{ textAlign: "left" }}>
              <p style={{ color: "#ff2b2b", fontWeight: 700, fontSize: 14, marginBottom: 2 }}>Email</p>
              <p style={{ color: "#aaa", fontSize: 14 }}>Coming Soon</p>
            </div>
          </div>

        </div>
      </section>
      <Footer />
    </>
  );
}
