import Footer from "@/components/Footer";

const rules = [
  { num: 1, rule: "Professional Behaviour", detail: "Har member, staff aur teammates ki respect karega. Toxicity, abuse, hate speech ya unnecessary drama allowed nahi hai." },
  { num: 2, rule: "Attendance & Punctuality", detail: "Scrims, practice aur tournaments mein time par present rehna mandatory hai. Late ya absent hone par pehle inform karna hoga." },
  { num: 3, rule: "Activity", detail: "Long inactivity bina notice ke allowed nahi hai. Agar break chahiye ho to management ko pehle batana hoga." },
  { num: 4, rule: "Team Discipline", detail: "IGL aur management ke decisions ka respect karna hoga. Team ke andar arguments ya fights public nahi karni hain." },
  { num: 5, rule: "Fair Play", detail: "Hacks, cheats, scripts, exploits ya third-party tools ka use strictly prohibited hai." },
  { num: 6, rule: "Confidentiality", detail: "Team strategies, trial plans, internal discussions aur management information leak karna mana hai." },
  { num: 7, rule: "Social Media", detail: "Organization ko represent karte waqt professional behaviour maintain karein. Fake announcements ya controversies create nahi karni." },
  { num: 8, rule: "Recruitment & Trials", detail: "Selection sirf performance, discipline aur attitude ke basis par hoga. Fake information dene par application reject ho sakti hai." },
  { num: 9, rule: "Streaming & Content", detail: "Official tournaments ke rules follow karne honge. Sponsor obligations aur branding guidelines ka respect karna hoga." },
  { num: 10, rule: "Leaving the Organization", detail: "Organization leave karne se pehle management ko inform karna mandatory hai. Internal assets ya confidential information leak nahi ki jayegi." },
  { num: 11, rule: "Punishment System", detail: "1st Violation: Verbal Warning | 2nd Violation: Written Warning | 3rd Violation: Suspension | Serious Misconduct: Direct Permanent Removal" },
  { num: 12, rule: "Management Rights", detail: "Prime Authority management kisi bhi member ko warning, suspension ya removal dene ka adhikar rakhti hai." },
];

export default function Rules() {
  return (
    <>
      <section style={{ padding: "80px 20px 20px", maxWidth: 900, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 40 }}>
          <h1 style={{ color: "#ff2b2b", fontSize: "clamp(1.5rem,4vw,2.5rem)", fontWeight: 900, letterSpacing: 2 }}>PRIME AUTHORITY – Official Organization Rules</h1>
          <p style={{ color: "#aaa", marginTop: 12 }}>These rules are mandatory for every member, staff, and team representative of Prime Authority.</p>
        </div>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", background: "#111", borderRadius: 12, overflow: "hidden" }}>
            <thead>
              <tr style={{ background: "#ff2b2b" }}>
                <th style={{ padding: "14px 20px", textAlign: "left", fontWeight: 700, color: "#fff", fontSize: 13 }}>#</th>
                <th style={{ padding: "14px 20px", textAlign: "left", fontWeight: 700, color: "#fff", fontSize: 13 }}>Rule</th>
                <th style={{ padding: "14px 20px", textAlign: "left", fontWeight: 700, color: "#fff", fontSize: 13 }}>Details</th>
              </tr>
            </thead>
            <tbody>
              {rules.map((r, i) => (
                <tr key={r.num} style={{ borderBottom: "1px solid #1a1a1a", background: i % 2 === 0 ? "#111" : "#0d0d0d" }}>
                  <td style={{ padding: "14px 20px", color: "#ff2b2b", fontWeight: 700 }}>{r.num}</td>
                  <td style={{ padding: "14px 20px", color: "#fff", fontWeight: 600, whiteSpace: "nowrap" }}>{r.rule}</td>
                  <td style={{ padding: "14px 20px", color: "#ccc", fontSize: 14, lineHeight: 1.6 }}>{r.detail}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <Footer />
    </>
  );
}
