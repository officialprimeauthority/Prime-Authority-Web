import { useEffect, useRef, useState } from "react";
import { ref, onValue, remove } from "firebase/database";
import { database } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";
import Footer from "@/components/Footer";

interface Notification {
  id: string;
  message: string;
  status: string;
  type: string;
  createdAt: string;
}

// Play a pleasant notification chime using Web Audio API
function playNotifSound() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const notes = [659.25, 783.99, 987.77]; // E5, G5, B5 — chime chord
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = "sine";
      osc.frequency.value = freq;
      const startTime = ctx.currentTime + i * 0.12;
      gain.gain.setValueAtTime(0, startTime);
      gain.gain.linearRampToValueAtTime(0.25, startTime + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.7);
      osc.start(startTime);
      osc.stop(startTime + 0.7);
    });
  } catch (_) {}
}

export default function Notifications() {
  const { user, loading } = useAuth();
  const [notifs, setNotifs] = useState<Notification[]>([]);
  const prevCountRef = useRef<number | null>(null);

  useEffect(() => {
    if (!user) return;
    const r = ref(database, `notifications/${user.uid}`);
    const unsub = onValue(r, (snap) => {
      if (!snap.exists()) { setNotifs([]); prevCountRef.current = 0; return; }
      const arr: Notification[] = Object.entries(snap.val()).map(([id, v]: any) => ({ id, ...v }));
      arr.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      // Play sound only when new notifications arrive (count increases)
      if (prevCountRef.current !== null && arr.length > prevCountRef.current) {
        playNotifSound();
      }
      prevCountRef.current = arr.length;
      setNotifs(arr);
    });
    return unsub;
  }, [user]);

  const deleteNotif = async (id: string) => {
    if (!user) return;
    await remove(ref(database, `notifications/${user.uid}/${id}`));
  };

  const statusColor = (s: string) => s === "Accepted" ? "#22c55e" : s === "Rejected" ? "#ef4444" : "#f59e0b";
  const statusBg   = (s: string) => s === "Accepted" ? "rgba(34,197,94,0.1)" : s === "Rejected" ? "rgba(239,68,68,0.1)" : "rgba(245,158,11,0.1)";

  return (
    <>
      <section style={{
        minHeight: "40vh", display: "flex", alignItems: "center", justifyContent: "center",
        textAlign: "center", padding: 20,
        background: "linear-gradient(rgba(0,0,0,.8),rgba(0,0,0,.9)), url('https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1600&q=80') center/cover",
      }}>
        <div>
          <h1 style={{ color: "#ff2b2b", fontWeight: 900, fontSize: "clamp(1.8rem,5vw,3rem)", textShadow: "0 0 15px #ff2b2b" }}>NOTIFICATIONS</h1>
          <h2 style={{ margin: "15px 0" }}>Your Updates</h2>
        </div>
      </section>

      <section style={{ maxWidth: 700, margin: "50px auto", padding: "0 20px 60px" }}>
        {loading ? (
          <p style={{ textAlign: "center", color: "#aaa" }}>Loading...</p>
        ) : !user ? (
          <div style={{ textAlign: "center", padding: "60px 20px" }}>
            <p style={{ color: "#aaa", fontSize: 16 }}>Please login to view your notifications.</p>
          </div>
        ) : notifs.length === 0 ? (
          <div style={{ textAlign: "center", padding: "60px 20px" }}>
            <div style={{ fontSize: 50, marginBottom: 15 }}>🔔</div>
            <p style={{ color: "#aaa", fontSize: 16 }}>No notifications yet.</p>
            <p style={{ color: "#666", fontSize: 13, marginTop: 8 }}>Once your form request is reviewed by admin, the status will appear here.</p>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 15 }}>
            {notifs.map(n => (
              <div key={n.id} style={{ background: "#111", border: "1px solid #222", borderRadius: 12, padding: 22, display: "flex", gap: 15, alignItems: "flex-start", position: "relative" }}>
                {/* Type icon */}
                <div style={{ fontSize: 24, marginTop: 2, flexShrink: 0 }}>
                  {n.type === "join" ? "📋" : n.type === "tournament" ? "🏆" : n.type === "scrim" ? "⚔️" : "🔔"}
                </div>

                {/* Content */}
                <div style={{ flex: 1 }}>
                  <p style={{ color: "#fff", fontWeight: 600, marginBottom: 6, paddingRight: 30 }}>{n.message}</p>
                  <span style={{
                    display: "inline-block", padding: "3px 12px", borderRadius: 20,
                    background: statusBg(n.status), color: statusColor(n.status),
                    fontSize: 12, fontWeight: 700,
                  }}>
                    {n.status || "Pending"}
                  </span>
                  {n.createdAt && (
                    <p style={{ color: "#666", fontSize: 12, marginTop: 8 }}>{new Date(n.createdAt).toLocaleString()}</p>
                  )}
                </div>

                {/* ✕ Dismiss button */}
                <button
                  onClick={() => deleteNotif(n.id)}
                  title="Remove notification"
                  style={{
                    position: "absolute", top: 12, right: 14,
                    background: "rgba(255,43,43,0.15)", border: "1px solid rgba(255,43,43,0.3)",
                    borderRadius: "50%", width: 26, height: 26,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    color: "#ff2b2b", fontSize: 14, fontWeight: 700,
                    cursor: "pointer", lineHeight: 1, padding: 0,
                  }}
                >✕</button>
              </div>
            ))}
          </div>
        )}
      </section>
      <Footer />
    </>
  );
}
