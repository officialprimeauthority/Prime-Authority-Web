import { Link } from "wouter";
import Footer from "@/components/Footer";

export default function Home() {
  const sectionStyle: React.CSSProperties = { padding: "80px 20px", textAlign: "center" };
  const redHeading: React.CSSProperties = { color: "#ff2b2b", fontWeight: 900, fontSize: "2.2rem", letterSpacing: 2, marginBottom: 15 };

  return (
    <>
      {/* Hero */}
      <section style={{
        minHeight: "100vh", display: "flex", justifyContent: "center", alignItems: "center",
        textAlign: "center", padding: 20,
        background: "linear-gradient(rgba(0,0,0,.75),rgba(0,0,0,.85)), url('https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1600&q=80') center/cover",
      }}>
        <div style={{ maxWidth: 750, animation: "fadeUp 1s ease" }}>
          <h1 style={{ fontSize: "clamp(2.5rem,8vw,4rem)", fontWeight: 900, color: "#ff2b2b", textShadow: "0 0 20px #ff2b2b" }}>PRIME AUTHORITY</h1>
          <h2 style={{ margin: "20px 0", fontSize: "clamp(1.2rem,4vw,1.8rem)" }}>Where Champions Are Made.</h2>
          <p style={{ fontSize: 18, lineHeight: 1.8, color: "#ddd", marginBottom: 30 }}>India's Professional Free Fire Esports Organization</p>
          <Link href="/join" style={{ padding: "15px 35px", borderRadius: 40, textDecoration: "none", fontWeight: 700, background: "#ff2b2b", color: "#fff", transition: ".3s", display: "inline-block" }}>
            Join Organization
          </Link>
        </div>
      </section>

      {/* Quick Links */}
      <section style={sectionStyle}>
        <h2 style={redHeading}>EXPLORE PRIME AUTHORITY</h2>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 20, justifyContent: "center", marginTop: 30 }}>
          {[
            { href: "/benefits", icon: "🎯", label: "Our Org Benefit" },
            { href: "/tournament", icon: "🏆", label: "Tournament Registration" },
            { href: "/scrims", icon: "⚔️", label: "Scrims Registration" },
          ].map(({ href, icon, label }) => (
            <Link key={href} href={href} style={{
              display: "block", padding: "22px 40px", background: "#111",
              border: "2px solid #ff2b2b", borderRadius: 12, color: "#fff",
              textDecoration: "none", fontWeight: 700, fontSize: 16,
              transition: ".3s", minWidth: 200,
            }}
              onMouseEnter={e => (e.currentTarget.style.boxShadow = "0 0 25px #ff2b2b")}
              onMouseLeave={e => (e.currentTarget.style.boxShadow = "none")}
            >
              {icon} {label}
            </Link>
          ))}
        </div>
      </section>

      {/* Stats */}
      <section style={{ padding: "40px 20px", display: "flex", flexWrap: "wrap", gap: 20, justifyContent: "center" }}>
        {[
          { val: "Coming Soon", label: "Official Squad" },
          { val: "24/7", label: "Community Support" },
          { val: "2026", label: "Established" },
        ].map(({ val, label }) => (
          <div key={label} style={{ background: "#111", border: "1px solid #222", borderRadius: 12, padding: "30px 40px", textAlign: "center", minWidth: 180 }}>
            <h2 style={{ color: "#ff2b2b", fontSize: "1.8rem", fontWeight: 800 }}>{val}</h2>
            <p style={{ color: "#aaa", marginTop: 5 }}>{label}</p>
          </div>
        ))}
      </section>

      {/* About */}
      <section style={{ ...sectionStyle, background: "#0d0d0d" }}>
        <h1 style={redHeading}>ABOUT PRIME AUTHORITY</h1>
        <p style={{ maxWidth: 700, margin: "0 auto", color: "#ccc", lineHeight: 1.8, fontSize: 16 }}>
          Prime Authority is a professional Free Fire Esports Organization built for players who want to compete at the highest level. Our mission is to create disciplined players, strong teams, and future champions through tournaments, scrims, and professional management.
        </p>
      </section>

      {/* Team */}
      <section style={sectionStyle}>
        <h1 style={redHeading}>OUR OFFICIAL TEAM</h1>
        <div style={{ display: "flex", justifyContent: "center", marginTop: 30 }}>
          <div style={{ background: "#111", border: "1px solid #222", borderRadius: 12, padding: 40, maxWidth: 400, textAlign: "center" }}>
            <h2 style={{ color: "#fff", marginBottom: 15 }}>Prime Authority Squad</h2>
            <p style={{ color: "#aaa", marginBottom: 25 }}>Our official competitive roster representing Prime Authority in scrims and tournaments.</p>
            <Link href="/mainroaster" style={{ padding: "12px 30px", background: "#ff2b2b", borderRadius: 30, color: "#fff", textDecoration: "none", fontWeight: 700 }}>
              Main Roaster
            </Link>
          </div>
        </div>
      </section>

      {/* Events */}
      <section style={{ ...sectionStyle, background: "#0d0d0d" }}>
        <h1 style={redHeading}>UPCOMING EVENTS</h1>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 20, justifyContent: "center", marginTop: 30 }}>
          <div style={{ background: "#111", border: "1px solid #333", borderRadius: 12, padding: 30, maxWidth: 300, textAlign: "center" }}>
            <h3 style={{ color: "#ff2b2b", marginBottom: 15 }}>🏆 PRIME AUTHORITY TOURNAMENT</h3>
            <p style={{ color: "#aaa" }}>Mode: Squad</p>
            <p style={{ color: "#aaa", margin: "8px 0" }}>Entry Fee: Coming Soon</p>
            <p style={{ color: "#aaa", marginBottom: 20 }}>Prize Pool: Coming Soon</p>
            <Link href="/tournament" style={{ display: "inline-block", padding: "10px 24px", background: "#ff2b2b", borderRadius: 20, color: "#fff", textDecoration: "none", fontWeight: 700, fontSize: 13 }}>
              REGISTER NOW
            </Link>
          </div>
          <div style={{ background: "#111", border: "1px solid #333", borderRadius: 12, padding: 30, maxWidth: 300, textAlign: "center" }}>
            <h3 style={{ color: "#ff2b2b", marginBottom: 15 }}>⚔️ PRIME SCRIMS</h3>
            <p style={{ color: "#aaa" }}>Daily Competitive Practice Matches</p>
            <p style={{ color: "#aaa", margin: "8px 0" }}>Entry Fee: Coming Soon</p>
            <div style={{ marginTop: 20 }}>
              <Link href="/scrims" style={{ display: "inline-block", padding: "10px 24px", background: "#ff2b2b", borderRadius: 20, color: "#fff", textDecoration: "none", fontWeight: 700, fontSize: 13 }}>
                JOIN SCRIMS
              </Link>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}
