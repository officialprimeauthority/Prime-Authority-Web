import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { auth, database } from "@/lib/firebase";
import { signOut } from "firebase/auth";
import { ref, onValue, update } from "firebase/database";
import { useAuth } from "@/lib/auth-context";
import AuthModal from "./AuthModal";

export default function Navbar() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [hidden, setHidden] = useState(false);
  const [lastY, setLastY] = useState(0);
  const [notifCount, setNotifCount] = useState(0);
  const [showAuth, setShowAuth] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editingName, setEditingName] = useState(false);
  const [newName, setNewName] = useState("");

  // Auto-hide on scroll
  useEffect(() => {
    const handleScroll = () => {
      const current = window.scrollY;
      if (current <= 0) { setHidden(false); setLastY(0); return; }
      if (Math.abs(current - lastY) > 8) {
        setHidden(current > lastY);
        setLastY(current);
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, [lastY]);

  // Notification count
  useEffect(() => {
    if (!user) { setNotifCount(0); return; }
    const r = ref(database, `notifications/${user.uid}`);
    const unsub = onValue(r, (snap) => {
      setNotifCount(snap.exists() ? Object.keys(snap.val()).length : 0);
    });
    return unsub;
  }, [user]);

  const handleAuthTrigger = () => {
    if (user) setDrawerOpen(true);
    else setShowAuth(true);
  };

  const handleLogout = async () => {
    await signOut(auth);
    setDrawerOpen(false);
    navigate("/");
  };

  const handleSaveName = async () => {
    if (!user || !newName.trim()) return;
    try {
      const { updateProfile } = await import("firebase/auth");
      await updateProfile(auth.currentUser!, { displayName: newName.trim() });
      await update(ref(database, `users/${user.uid}`), { fullName: newName.trim() });
      setEditingName(false);
    } catch (e: any) { alert(e.message); }
  };

  const initial = (user?.displayName || user?.email || "U").trim().charAt(0).toUpperCase();

  return (
    <>
      <header
        style={{
          position: "fixed", top: 0, left: 0, width: "100%", zIndex: 9999,
          background: "rgba(0,0,0,0.92)", backdropFilter: "blur(12px)",
          borderBottom: "1px solid rgba(255,43,43,0.3)",
          transform: hidden ? "translateY(-100%)" : "translateY(0)",
          transition: "transform 0.35s ease",
        }}
      >
        <nav style={{ maxWidth: 1300, margin: "auto", display: "flex", justifyContent: "space-between", alignItems: "center", padding: "18px 30px" }}>
          <Link href="/" style={{ fontSize: 28, fontWeight: 900, color: "#ff2b2b", letterSpacing: 2, textDecoration: "none" }}>
            PRIME AUTHORITY
          </Link>
          <ul style={{ display: "flex", alignItems: "center", listStyle: "none", gap: 25 }}>
            {/* Notification Bell */}
            <li>
              <Link
                href="/notifications"
                onClick={e => { if (!user) { e.preventDefault(); alert("Please login or sign up first to view your notifications."); setShowAuth(true); } }}
                style={{ color: "#fff", textDecoration: "none", fontSize: 22, position: "relative", display: "inline-block" }}
              >
                🔔
                <span style={{
                  position: "absolute", top: -8, right: -12,
                  background: "#ff2b2b", borderRadius: "50%", padding: "0 5px",
                  fontSize: 11, fontWeight: 700, color: "#fff", minWidth: 18,
                  height: 18, lineHeight: "18px", textAlign: "center",
                }}>{notifCount}</span>
              </Link>
            </li>
            {/* Auth Trigger — Login text OR profile pill */}
            <li>
              {user ? (
                <button
                  onClick={handleAuthTrigger}
                  style={{
                    width: 40, height: 40, borderRadius: "50%", background: "#ff2b2b",
                    color: "#fff", display: "grid", placeItems: "center",
                    fontWeight: 800, fontSize: 16, border: "none", cursor: "pointer",
                    fontFamily: "Poppins, sans-serif",
                  }}
                >{initial}</button>
              ) : (
                <button
                  onClick={handleAuthTrigger}
                  style={{
                    background: "none", border: "none", color: "#fff",
                    fontWeight: 600, cursor: "pointer", fontFamily: "Poppins, sans-serif",
                    fontSize: 15, textDecoration: "none",
                  }}
                >Login</button>
              )}
            </li>
          </ul>
        </nav>
      </header>

      {/* Profile Drawer — matches original */}
      {drawerOpen && (
        <div
          style={{ position: "fixed", inset: 0, zIndex: 10001 }}
          onClick={() => { setDrawerOpen(false); setEditingName(false); }}
        >
          <div
            style={{
              position: "absolute", top: 0, right: 0,
              width: "min(100%, 380px)", height: "100vh",
              background: "#0f0f0f", borderLeft: "1px solid #ff2b2b",
              boxShadow: "-10px 0 35px rgba(0,0,0,.45)",
              padding: 24, display: "flex", flexDirection: "column", gap: 18,
              animation: "slideIn 0.3s ease",
            }}
            onClick={e => e.stopPropagation()}
          >
            {/* Close */}
            <button
              onClick={() => { setDrawerOpen(false); setEditingName(false); }}
              style={{ position: "absolute", top: 12, right: 12, background: "transparent", border: "none", color: "#fff", fontSize: 28, cursor: "pointer" }}
            >×</button>

            {/* Avatar + Name */}
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 20 }}>
              <div style={{ width: 54, height: 54, borderRadius: "50%", background: "#ff2b2b", display: "grid", placeItems: "center", fontSize: 22, fontWeight: 800, color: "#fff", flexShrink: 0 }}>
                {initial}
              </div>
              <div style={{ flex: 1 }}>
                {editingName ? (
                  <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                    <input
                      value={newName}
                      onChange={e => setNewName(e.target.value)}
                      style={{ flex: 1, padding: "6px 10px", borderRadius: 8, border: "1px solid #ff2b2b", background: "#111", color: "#fff", fontFamily: "Poppins, sans-serif", fontSize: 13 }}
                      autoFocus
                    />
                    <button onClick={handleSaveName} style={{ background: "#1a1a1a", border: "1px solid #ff2b2b", color: "#fff", padding: "6px 10px", borderRadius: 999, cursor: "pointer", fontSize: 12 }}>Save</button>
                  </div>
                ) : (
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <h3 style={{ color: "#fff", fontWeight: 700, margin: 0 }}>{user?.displayName || "Player"}</h3>
                    <button
                      onClick={() => { setEditingName(true); setNewName(user?.displayName || ""); }}
                      style={{ background: "#1a1a1a", border: "1px solid #ff2b2b", color: "#fff", padding: "4px 10px", borderRadius: 999, cursor: "pointer", fontSize: 12 }}
                    >Edit</button>
                  </div>
                )}
              </div>
            </div>

            {/* Email */}
            <div>
              <p style={{ fontSize: 12, color: "#888", textTransform: "uppercase", letterSpacing: 1, margin: 0 }}>Email Address</p>
              <p style={{ fontSize: 15, color: "#fff", marginTop: 4 }}>{user?.email}</p>
            </div>

            {/* Nav Links — same as original */}
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {[
                { href: "/", label: "Home" },
                { href: "/join", label: "Join" },
                { href: "/tournament", label: "Tournament" },
                { href: "/scrims", label: "Scrims" },
                { href: "/contact", label: "Contact" },
              ].map(({ href, label }) => (
                <Link
                  key={href}
                  href={href}
                  onClick={() => setDrawerOpen(false)}
                  style={{ color: "#fff", textDecoration: "none", padding: "10px 12px", borderRadius: 10, background: "#171717", fontWeight: 600, display: "block" }}
                >
                  {label}
                </Link>
              ))}
            </div>

            {/* Notifications link */}
            <Link
              href="/notifications"
              onClick={() => setDrawerOpen(false)}
              style={{ color: "#fff", textDecoration: "none", padding: "10px 12px", borderRadius: 10, background: "#171717", fontWeight: 600, display: "block" }}
            >
              🔔 Notifications
            </Link>

            {/* Logout */}
            <button
              onClick={handleLogout}
              style={{ marginTop: "auto", width: "100%", padding: "14px", background: "#ff2b2b", border: "none", borderRadius: 40, color: "#fff", fontSize: 15, fontWeight: 700, cursor: "pointer", fontFamily: "Poppins, sans-serif" }}
            >
              Logout
            </button>
          </div>
        </div>
      )}

      {showAuth && <AuthModal onClose={() => setShowAuth(false)} />}
    </>
  );
}
