import { useState } from "react";
import { auth, database } from "@/lib/firebase";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile,
  sendPasswordResetEmail,
} from "firebase/auth";
import { ref, set } from "firebase/database";

interface Props { onClose: () => void; }
type Mode = "login" | "signup" | "forgot";

// SVG Eye icons
const EyeOpen = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff2b2b" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
    <circle cx="12" cy="12" r="3"/>
  </svg>
);
const EyeOff = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff2b2b" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
    <line x1="1" y1="1" x2="23" y2="23"/>
  </svg>
);

export default function AuthModal({ onClose }: Props) {
  const [mode, setMode] = useState<Mode>("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);

  const resetState = () => { setError(""); setSuccess(""); };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    resetState();
    setLoading(true);
    try {
      if (mode === "login") {
        await signInWithEmailAndPassword(auth, email, password);
        onClose();
      } else if (mode === "signup") {
        if (password !== confirmPassword) { setError("Passwords do not match."); setLoading(false); return; }
        const cred = await createUserWithEmailAndPassword(auth, email, password);
        if (name) await updateProfile(cred.user, { displayName: name });
        await set(ref(database, `users/${cred.user.uid}`), {
          fullName: name, email, createdAt: new Date().toISOString(),
        });
        onClose();
      } else {
        await sendPasswordResetEmail(auth, email);
        setSuccess("A password reset link has been sent to your email. Please check your inbox.");
      }
    } catch (err: any) {
      setError(err.message || "An error occurred.");
    } finally {
      setLoading(false);
    }
  };

  const cardStyle: React.CSSProperties = {
    position: "relative", width: "min(100%, 480px)", background: "#121212",
    border: "1px solid #ff2b2b", borderRadius: 24, padding: "30px 24px 24px",
    boxShadow: "0 0 35px rgba(255,43,43,.25)",
  };
  const labelStyle: React.CSSProperties = { color: "#fff", fontSize: 14, fontWeight: 600 };
  const wrapStyle: React.CSSProperties = {
    display: "flex", alignItems: "center", background: "#1a1a1a",
    border: "1px solid rgba(255,255,255,.15)", borderRadius: 12, overflow: "hidden",
  };
  const inputStyle: React.CSSProperties = {
    flex: 1, padding: "12px 14px", background: "transparent",
    border: "none", color: "#fff", outline: "none",
    fontFamily: "Poppins, sans-serif", fontSize: 14,
  };
  const eyeBtnStyle: React.CSSProperties = {
    background: "transparent", border: "none", cursor: "pointer",
    padding: "0 12px", display: "flex", alignItems: "center",
  };
  const submitBtnStyle: React.CSSProperties = {
    width: "100%", padding: "14px 20px", background: "#ff2b2b", border: "none",
    borderRadius: 40, color: "#fff", fontSize: 16, fontWeight: 700,
    cursor: loading ? "not-allowed" : "pointer", fontFamily: "Poppins, sans-serif",
    marginTop: 8, opacity: loading ? 0.7 : 1,
  };
  const subtitleStyle: React.CSSProperties = { fontSize: 14, color: "#bbb", margin: "4px 0 16px" };
  const switchStyle: React.CSSProperties = { fontSize: 14, color: "#bbb", marginTop: 12, textAlign: "center" };
  const redBtn: React.CSSProperties = {
    color: "#ff2b2b", fontWeight: 700, cursor: "pointer",
    background: "none", border: "none", fontFamily: "Poppins, sans-serif", fontSize: 14,
  };
  const formStyle: React.CSSProperties = { display: "flex", flexDirection: "column", gap: 12 };

  return (
    <div
      style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.82)", zIndex: 10001, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}
      onClick={onClose}
    >
      <div style={cardStyle} onClick={e => e.stopPropagation()}>
        <button onClick={onClose} style={{ position: "absolute", top: 12, right: 12, background: "transparent", border: "none", color: "#fff", fontSize: 28, cursor: "pointer", lineHeight: 1 }}>×</button>

        {/* LOGIN */}
        {mode === "login" && (
          <>
            <h2 style={{ color: "#ff2b2b", fontWeight: 800, fontSize: "1.4rem" }}>Player Login</h2>
            <p style={subtitleStyle}>Access your Prime Authority profile</p>
            {error && <p style={{ color: "#ff2b2b", fontSize: 13, padding: "8px 12px", background: "rgba(255,43,43,0.1)", borderRadius: 8, marginBottom: 8 }}>{error}</p>}
            <form onSubmit={handleSubmit} style={formStyle}>
              <label style={labelStyle}>Email</label>
              <div style={wrapStyle}>
                <input style={inputStyle} type="email" placeholder="Enter your gmail" value={email} onChange={e => setEmail(e.target.value)} required />
              </div>
              <label style={labelStyle}>Password</label>
              <div style={wrapStyle}>
                <input style={inputStyle} type={showPass ? "text" : "password"} placeholder="Enter your password" value={password} onChange={e => setPassword(e.target.value)} required />
                <button type="button" style={eyeBtnStyle} onClick={() => setShowPass(v => !v)}>{showPass ? <EyeOff /> : <EyeOpen />}</button>
              </div>
              <button type="button" onClick={() => { setMode("forgot"); resetState(); }} style={{ ...redBtn, alignSelf: "flex-end", fontSize: 13 }}>Forget password?</button>
              <button type="submit" style={submitBtnStyle} disabled={loading}>{loading ? "Please wait..." : "Login"}</button>
              <p style={switchStyle}>New player? <button type="button" onClick={() => { setMode("signup"); resetState(); }} style={redBtn}>Create New Profile</button></p>
            </form>
          </>
        )}

        {/* SIGNUP */}
        {mode === "signup" && (
          <>
            <h2 style={{ color: "#ff2b2b", fontWeight: 800, fontSize: "1.4rem" }}>Player Sign Up</h2>
            <p style={subtitleStyle}>Create your player profile</p>
            {error && <p style={{ color: "#ff2b2b", fontSize: 13, padding: "8px 12px", background: "rgba(255,43,43,0.1)", borderRadius: 8, marginBottom: 8 }}>{error}</p>}
            <form onSubmit={handleSubmit} style={formStyle}>
              <label style={labelStyle}>Full Name</label>
              <div style={wrapStyle}>
                <input style={inputStyle} type="text" placeholder="Enter your full name" value={name} onChange={e => setName(e.target.value)} required />
              </div>
              <label style={labelStyle}>Email</label>
              <div style={wrapStyle}>
                <input style={inputStyle} type="email" placeholder="Enter your gmail" value={email} onChange={e => setEmail(e.target.value)} required />
              </div>
              <label style={labelStyle}>Password</label>
              <div style={wrapStyle}>
                <input style={inputStyle} type={showPass ? "text" : "password"} placeholder="Enter your password" value={password} onChange={e => setPassword(e.target.value)} required />
                <button type="button" style={eyeBtnStyle} onClick={() => setShowPass(v => !v)}>{showPass ? <EyeOff /> : <EyeOpen />}</button>
              </div>
              <label style={labelStyle}>Confirm Password</label>
              <div style={wrapStyle}>
                <input style={inputStyle} type={showConfirm ? "text" : "password"} placeholder="Confirm your password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required />
                <button type="button" style={eyeBtnStyle} onClick={() => setShowConfirm(v => !v)}>{showConfirm ? <EyeOff /> : <EyeOpen />}</button>
              </div>
              <button type="submit" style={submitBtnStyle} disabled={loading}>{loading ? "Please wait..." : "Sign Up"}</button>
              <p style={switchStyle}>Already have an account? <button type="button" onClick={() => { setMode("login"); resetState(); }} style={redBtn}>Login Here</button></p>
            </form>
          </>
        )}

        {/* FORGOT */}
        {mode === "forgot" && (
          <>
            <h2 style={{ color: "#ff2b2b", fontWeight: 800, fontSize: "1.4rem" }}>Reset Password</h2>
            <p style={subtitleStyle}>Enter your registered email to receive a password reset link</p>
            {error && <p style={{ color: "#ff2b2b", fontSize: 13, padding: "8px 12px", background: "rgba(255,43,43,0.1)", borderRadius: 8, marginBottom: 8 }}>{error}</p>}
            {success && <p style={{ color: "#22c55e", fontSize: 13, padding: "8px 12px", background: "rgba(34,197,94,0.1)", borderRadius: 8, marginBottom: 8 }}>{success}</p>}
            <form onSubmit={handleSubmit} style={formStyle}>
              <label style={labelStyle}>Email</label>
              <div style={wrapStyle}>
                <input style={inputStyle} type="email" placeholder="Enter your gmail" value={email} onChange={e => setEmail(e.target.value)} required />
              </div>
              <button type="submit" style={submitBtnStyle} disabled={loading}>{loading ? "Please wait..." : "Send Reset Link"}</button>
              <p style={switchStyle}>Remembered it? <button type="button" onClick={() => { setMode("login"); resetState(); }} style={redBtn}>Back to Login</button></p>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
