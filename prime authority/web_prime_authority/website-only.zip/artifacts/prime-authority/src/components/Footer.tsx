export default function Footer() {
  return (
    <footer style={{
      textAlign: "center",
      padding: "40px 20px",
      background: "#0a0a0a",
      borderTop: "1px solid #1a1a1a",
      marginTop: 60,
    }}>
      <h2 style={{ color: "#ff2b2b", fontSize: 24, fontWeight: 900, letterSpacing: 2 }}>PRIME AUTHORITY</h2>
      <p style={{ color: "#aaa", marginTop: 8 }}>Where Champions Are Made.</p>
      <p style={{ color: "#555", marginTop: 5, fontSize: 13 }}>© 2026 Prime Authority. All Rights Reserved.</p>
    </footer>
  );
}
