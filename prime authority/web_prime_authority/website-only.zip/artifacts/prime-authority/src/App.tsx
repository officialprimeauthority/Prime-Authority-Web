import { useEffect, useState } from "react";
import { Route, Switch, Router as WouterRouter } from "wouter";
import { AuthProvider } from "@/lib/auth-context";
import Navbar from "@/components/Navbar";
import Home from "@/pages/Home";
import Join from "@/pages/Join";
import Tournament from "@/pages/Tournament";
import Scrims from "@/pages/Scrims";
import Notifications from "@/pages/Notifications";
import Benefits from "@/pages/Benefits";
import Rules from "@/pages/Rules";
import Contact from "@/pages/Contact";
import MainRoaster from "@/pages/MainRoaster";
import AdminLogin from "@/pages/admin/AdminLogin";
import AdminDashboard from "@/pages/admin/AdminDashboard";

function Loader() {
  const [opacity, setOpacity] = useState(1);
  const [gone, setGone] = useState(false);
  useEffect(() => {
    const t1 = setTimeout(() => setOpacity(0), 800);
    const t2 = setTimeout(() => setGone(true), 1300);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, []);
  if (gone) return null;
  return (
    <div style={{
      position: "fixed", inset: 0, background: "#0b0b0b",
      display: "flex", alignItems: "center", justifyContent: "center",
      zIndex: 99999, opacity, transition: "opacity 0.5s ease", pointerEvents: gone ? "none" : "auto"
    }}>
      <div style={{ fontSize: "2rem", fontWeight: 900, color: "#ff2b2b", letterSpacing: 4, animation: "pulse 1.5s ease-in-out infinite" }}>PRIME AUTHORITY</div>
    </div>
  );
}

function PublicLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navbar />
      {children}
    </>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={() => <PublicLayout><Home /></PublicLayout>} />
      <Route path="/join" component={() => <PublicLayout><Join /></PublicLayout>} />
      <Route path="/tournament" component={() => <PublicLayout><Tournament /></PublicLayout>} />
      <Route path="/scrims" component={() => <PublicLayout><Scrims /></PublicLayout>} />
      <Route path="/notifications" component={() => <PublicLayout><Notifications /></PublicLayout>} />
      <Route path="/benefits" component={() => <PublicLayout><Benefits /></PublicLayout>} />
      <Route path="/rules" component={() => <PublicLayout><Rules /></PublicLayout>} />
      <Route path="/contact" component={() => <PublicLayout><Contact /></PublicLayout>} />
      <Route path="/mainroaster" component={() => <PublicLayout><MainRoaster /></PublicLayout>} />
      {/* Admin routes - no public navbar */}
      <Route path="/admin" component={AdminLogin} />
      <Route path="/admin/dashboard" component={AdminDashboard} />
      <Route component={() => (
        <PublicLayout>
          <div style={{ minHeight: "80vh", display: "flex", alignItems: "center", justifyContent: "center", textAlign: "center" }}>
            <div>
              <h1 style={{ color: "#ff2b2b", fontSize: "4rem", fontWeight: 900 }}>404</h1>
              <p style={{ color: "#aaa" }}>Page not found.</p>
            </div>
          </div>
        </PublicLayout>
      )} />
    </Switch>
  );
}

export default function App() {
  const base = import.meta.env.BASE_URL.replace(/\/$/, "");
  return (
    <AuthProvider>
      <Loader />
      <WouterRouter base={base}>
        <Router />
      </WouterRouter>
    </AuthProvider>
  );
}
