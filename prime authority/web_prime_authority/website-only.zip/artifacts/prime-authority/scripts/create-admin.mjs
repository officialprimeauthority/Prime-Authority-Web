// One-time script to create the admin user in Firebase Auth
import { initializeApp } from "firebase/app";
import { getAuth, createUserWithEmailAndPassword } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyBm6V2_CR2GnD7hZC27VSJnL-zdbxAERkg",
  authDomain: "prime-authority.firebaseapp.com",
  databaseURL: "https://prime-authority-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "prime-authority",
  storageBucket: "prime-authority.firebasestorage.app",
  messagingSenderId: "394958687244",
  appId: "1:394958687244:web:629c04e964a7859f9c3229",
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

const ADMIN_EMAIL = "admin@primeauthority.com";
const ADMIN_PASS  = "PrimeAuthority@2026";

try {
  const cred = await createUserWithEmailAndPassword(auth, ADMIN_EMAIL, ADMIN_PASS);
  console.log("✅ Admin user created successfully!");
  console.log("   UID:", cred.user.uid);
  console.log("   Email:", cred.user.email);
} catch (err) {
  if (err.code === "auth/email-already-in-use") {
    console.log("ℹ️  Admin user already exists in Firebase — credentials are correct.");
  } else {
    console.error("❌ Error:", err.code, err.message);
  }
}

process.exit(0);
